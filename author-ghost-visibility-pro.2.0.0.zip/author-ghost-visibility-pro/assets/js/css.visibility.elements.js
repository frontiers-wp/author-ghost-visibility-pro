/**
 * Function to safely output CSS styles for hiding elements
 *
 * @param {Object} cssSelectors - Associative object of CSS selectors and their styles
 */
function simplyHideAuthorElementsByCSS(cssSelectors) {
    if (!cssSelectors || typeof cssSelectors !== 'object' || Object.keys(cssSelectors).length === 0) {
        return;
    }

    // Allowed CSS properties and values
    const allowedProperties = {
        'display': ['none', 'block', 'inline', 'inline-block', 'flex', 'grid'],
        'visibility': ['hidden', 'visible']
    };

    // Create a style element
    const styleElement = document.createElement('style');
    styleElement.type = 'text/css';

    // Process each selector
    for (const [selector, style] of Object.entries(cssSelectors)) {
        // Sanitize the CSS selector
        const sanitizedSelector = selector.replace(/[^a-zA-Z0-9#.:,[\]>\s\-_()=!]/g, '');

        // Sanitize the CSS style
        let sanitizedStyle = style.replace(/[^a-zA-Z0-9\s\-:;!]/g, '');

        // Check if the style contains allowed properties
        const styleParts = sanitizedStyle.split(';').filter(part => part.trim() !== '');
        const validStyleParts = [];

        for (const part of styleParts) {
            const [property, value] = part.split(':').map(item => item.trim());
            if (property && value && allowedProperties[property] && allowedProperties[property].includes(value)) {
                validStyleParts.push(`${property}: ${value}`);
            }
        }

        if (sanitizedSelector && validStyleParts.length > 0) {
            // Add the rule to the style element
            styleElement.textContent += `${sanitizedSelector} { ${validStyleParts.join('; ')} } `;
        }
    }

    // Append the style element to the head
    if (styleElement.textContent.trim() !== '') {
        document.head.appendChild(styleElement);
    }
}

// Define the CSS selectors and their corresponding styles
const simplyHideAuthorCSSSelectors = {
    '.entry-meta ul li:before': 'display: none !important',
    '.entry-meta .byline:after': 'display: none !important',
    '.entry-meta .byline, .author-info': 'display: none',
    'ul li.meta-author': 'display: none !important',
    '.entry-meta .byline': 'display: none !important',
    '.entry-meta .cat-links': 'display: none !important',
    '.post .author-name': 'display: none !important',
    '.author-name': 'display: none !important',
    '.post-author': 'display: none !important; visibility: hidden',
    '.author-name-class': 'display: none !important',
    '.authorbox': 'display: none !important',
    '.entry-author': 'display: none !important',
    '.entry-meta .posted-on': 'display: none !important',
    '.entry-meta .author.vcard': 'display: none !important',
    '.post-author.meta-wrapper': 'display: none !important',
    '.mkdf-post-info-author': 'display: none !important',
    '.amp-wp-meta': 'display: none !important'
};

// Call the function to output the CSS
simplyHideAuthorElementsByCSS(simplyHideAuthorCSSSelectors);
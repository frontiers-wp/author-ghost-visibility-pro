<?php if (!defined('ABSPATH')) die();

use Frontiers\author_ghost_visibility_pro\Plugin;

function author_ghost_visibility_pro_nonce_field(){
	Plugin::instance()->nonceField();
}
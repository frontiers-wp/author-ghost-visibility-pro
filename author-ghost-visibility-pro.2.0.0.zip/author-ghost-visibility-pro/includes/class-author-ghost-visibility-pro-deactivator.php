<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      2.0.0
 * @package    author_ghost_visibility_pro
 * @subpackage author_ghost_visibility_pro/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */
class author_ghost_visibility_pro_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    2.0.0
	 */
	public static function deactivate() {

	}
    
	/**
	 * Specify all codes required for plugin uninstall here.
	 *
	 */
	public function uninstall() {
        // delete plugin options
        delete_option('author_ghost_visibility_pro_options');
        // delete plugin transient
        delete_transient('author_ghost_visibility_pro_transient');
        // Delete plugin version
        delete_option( 'author_ghost_visibility_pro_plugin_version' );
    }

}
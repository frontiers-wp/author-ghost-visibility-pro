<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      2.0.0
 * @package    author_ghost_visibility_pro
 * @subpackage author_ghost_visibility_pro/includes
 * @author     Frontiers <wordpress@bekamhealing.com>
 */

if (!class_exists('author_ghost_visibility_pro_Activator')) {

    class author_ghost_visibility_pro_Activator {

        /**
         * Main activation handler.
         * Initializes plugin options and sets up uninstall hook.
         *
         * @since    2.0.0
         */
        public static function activate() {
            $activator = new self();
            $activator->install();

            // Register uninstall hook
            register_uninstall_hook(__FILE__, ['author_ghost_visibility_pro_Activator', 'uninstall']);
        }

        /**
         * Initializes plugin options during activation.
         *
         * @since    2.0.0
         */
        protected function install() {
           // $init_options();
        }

        /**
         * Uninstall handler.
         * Cleans up plugin data when uninstalled.
         *
         * @since    2.0.0
         */
        public static function uninstall() {
            // Uninstall cleanup
            delete_option('author_ghost_visibility_pro_options');
        }
    }
}
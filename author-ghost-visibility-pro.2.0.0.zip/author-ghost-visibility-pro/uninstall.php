<?php
/**
 * Fired when the plugin is uninstalled.
 * For more information, see the following discussion:
 * https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/pull/123#issuecomment-28541913
 *
 * @link       https://https://wordpress.org/plugins/simply-hide-author-name
 * @since      2.0.0
 *
 * @package    Simply_Hide_Author
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove Option on uninstalling/deleting the Plugin.
 */
function author_ghost_visibility_pro_plugin_version_uninstall() {
	delete_option( 'author_ghost_visibility_pro_plugin_version' );
}

/**
 * Remove Fields on uninstalling/deleting the Plugin.
 */
delete_option('author_ghost_visibility_pro_plugin_fields');
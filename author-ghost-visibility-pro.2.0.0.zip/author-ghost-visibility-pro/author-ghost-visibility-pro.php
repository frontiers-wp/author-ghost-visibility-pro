<?php
/**
 * @wordpress-plugin
 * Plugin Name:       Author Ghost Visibility Pro
 * Plugin URI:        https://wordpress.org/plugins/simply-hide-author-name
 * Description:       Hide author name from your WordPress blog
 * Version:           2.0.0
 * Requires at least: 5.0
 * Requires PHP:      7.4
 * Author:            Edwin Bekedam
 * Author URI:        https://github.com/frontiers-wp/author-ghost-visibility-pro
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       author-ghost-visibility-pro
 * Domain Path:       /languages
 * License:           GPLv2
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *
 * You should have received a copy of the GNU General Public License
 * along with Author Ghost Visibility Pro. If not, see <https://www.gnu.org/licenses/gpl-2.0.html/>.
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'AUTHOR_GHOST_VISIBILITY_PRO_VERSION', '2.0.0' );

/**
 * Base URL of plugin
 */
if ( ! defined( 'AUTHOR_GHOST_VISIBILITY_PRO_NAME_BASEURL' ) ) {
	define( 'AUTHOR_GHOST_VISIBILITY_PRO_NAME_BASEURL', plugin_dir_url( __FILE__ ) );
}

/**
 * Base Name of plugin
 */
if ( ! defined( 'AUTHOR_GHOST_VISIBILITY_PRO_NAME_BASENAME' ) ) {
	define( 'AUTHOR_GHOST_VISIBILITY_PRO_NAME_BASENAME', plugin_basename( __FILE__ ) );
}

/**
 * Base PATH of plugin
 */
if ( ! defined( 'AUTHOR_GHOST_VISIBILITY_PRO_NAME_BASEPATH' ) ) {
	define( 'AUTHOR_GHOST_VISIBILITY_PRO_NAME_BASEPATH', plugin_dir_path( __FILE__ ) );
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-author-ghost-visibility-pro-activator.php
 */
function author_ghost_visibility_pro_activate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-author-ghost-visibility-pro-activator.php';
	author_ghost_visibility_pro_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-author-ghost-visibility-pro-deactivator.php
 */
function author_ghost_visibility_pro_deactivate() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-author-ghost-visibility-pro-deactivator.php';
	author_ghost_visibility_pro_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'author_ghost_visibility_pro_activate' );
register_deactivation_hook( __FILE__, 'author_ghost_visibility_pro_deactivate' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-author-ghost-visibility-pro.php';
require plugin_dir_path( __FILE__ ) . 'includes/class-author-ghost-visibility-pro-elements.php';